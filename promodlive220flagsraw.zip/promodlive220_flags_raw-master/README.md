# About Call of Duty 4 Source
Source create on 16.1.2018

# About Developer's 
+ Developer's: CWP-Razor, jEENN, Night
+ Custom Menu & Material's: ZaGGoreC, Night

# What is new?
 + Custom Menu
 + 252 Country Flags
 + Field of View and Fullbright /bind key 8 and 9
 + New FinalKillcam with music - Only for Search & Destroy Gametype
 + New In-Game Font
 + GeoIP Location
 + KD Ratio
 + Anti camp script
 
 
 
